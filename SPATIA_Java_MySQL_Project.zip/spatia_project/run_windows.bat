@echo off
setlocal
set JAR=mysql-connector-j-9.5.0.jar
if not exist "%JAR%" (
  echo MySQL Connector/J not found: %JAR%
  echo Download Connector/J and place the JAR beside this file.
  pause
  exit /b 1
)
javac -cp ".;%JAR%" SpatiaServer.java
if errorlevel 1 pause & exit /b 1
java -cp ".;%JAR%" SpatiaServer
